
<div>
    <?php $__currentLoopData = $persona['campos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($value->Field != 'id'  && $value->Field != 'created_at' && $value->Field != 'updated_at'): ?>
            <label for="<?php echo e($value->Field); ?>"><?php echo e(__('adminlte::adminlte.'.$value->Field)); ?></label>
            <?php if($value->Type == "text" || $value->Type == "varchar(255)"): ?>
                <input type="text" name="<?php echo e($value->Field); ?>" id="<?php echo e($value->Field); ?>" class="form-control <?php echo e($errors->has($value->Field) ? 'is-invalid' : ''); ?>">
            <?php elseif($value->Type == "integer" || $value->Type == "bigint" || $value->Type == "int" ): ?>
                <input type="number" name="<?php echo e($value->Field); ?>" id="<?php echo e($value->Field); ?>" class="form-control <?php echo e($errors->has($value->Field) ? 'is-invalid' : ''); ?>">
            <?php elseif($value->Type == "decimal(8,2)" || $value->Type == "decimal" || $value->Type == "float" || $value->Type == "numeric" || $value->Type == "double precision" || $value->Type == "double"): ?>
                <input type="number" name="<?php echo e($value->Field); ?>" id="<?php echo e($value->Field); ?>" class="form-control <?php echo e($errors->has($value->Field) ? 'is-invalid' : ''); ?>" step="any">
            <?php elseif($value->Type == "date"): ?>
                <input type="date" name="<?php echo e($value->Field); ?>" id="<?php echo e($value->Field); ?>" class="form-control <?php echo e($errors->has($value->Field) ? 'is-invalid' : ''); ?>">
            <?php elseif($value->Field == "tipo_personas_id" || $value->Field == 'estatus_id' || $value->Field == 'ascensos_id'): ?>
                <select name="<?php echo e($value->Field); ?>" id="<?php echo e($value->Field); ?>" class="form-control <?php echo e($errors->has($value->Field) ? 'is-invalid' : ''); ?>">
                    <option value="0">Seleccionar una opcion</option>
                    <?php switch($value->Field):
                        case ("tipo_personas_id"): ?>
                            <?php $__currentLoopData = $persona['tipoPersona']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($option['id']); ?>"><?php echo e($option['nombre']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php break; ?>
                        <?php case ('estatus_id'): ?>
                            <?php $__currentLoopData = $persona['status']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($option['id']); ?>"><?php echo e($option['nombre']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php break; ?>
                        <?php case ('ascensos_id'): ?>
                            <?php $__currentLoopData = $persona['ascensos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($option['id']); ?>"><?php echo e($option['nombre']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php break; ?>
                    <?php endswitch; ?>
                </select>
            <?php endif; ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\Users\Alexander\Desktop\workspace\exploradores\Erv\resources\views/partials/forms/personas.blade.php ENDPATH**/ ?>