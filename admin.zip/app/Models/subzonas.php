<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class subzonas extends Model
{
    use HasFactory;
    protected $table = 'subzonas';
}
