<?php $__env->startSection('title', 'AdminLTE'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="m-0 text-dark">Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <form id="NewRegister" method="POST" <?php echo e($file ? 'enctype="multipart/form-data"' : ''); ?>>
                    <div class="card-body">
                        <?php echo e(csrf_field()); ?>

                        <?php $__currentLoopData = $campos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($campos[$key]->Field != 'id' && $campos[$key]->Field != 'created_at' && $campos[$key]->Field != 'updated_at' && $campos[$key]->Field != 'estatus_id'): ?>
                                <div class="form-group">
                                    <?php
                                        $label = "";
                                        switch ($campos[$key]->Field) {
                                            case 'cuota_id':
                                                $label= "Cuota";
                                                break;
                                            case 'estatus_id':
                                                $label= "Estatus";
                                                break;
                                            case 'zona_id':
                                                $label= "Zona";
                                                break;
                                            default:
                                                $label= $campos[$key]->Field;
                                                break;
                                        }
                                    ?>
                                    <label for="<?php echo e($campos[$key]->Field); ?>"><?php echo e(__('adminlte::adminlte.'.$label)); ?></label>
                                    <?php if($campos[$key]->Field == "categoria_id" ||$campos[$key]->Field == "cuota_id" || $campos[$key]->Field == 'estatus_id' || $campos[$key]->Field == 'zona_id'): ?>
                                        <select name="<?php echo e($campos[$key]->Field); ?>" id="<?php echo e($campos[$key]->Field); ?>" class="form-control <?php echo e($errors->has($campos[$key]->Field) ? 'is-invalid' : ''); ?>">
                                            <option value="0">Seleccionar una opcion</option>
                                            <?php switch($campos[$key]->Field):
                                                case ("cuota_id"): ?>
                                                    <?php $__currentLoopData = $cuota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($option['id']); ?>"><?php echo e($option['nombre']." ".$option['monto']." ".$option['fecha']); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php break; ?>
                                                <?php case ('estatus_id'): ?>
                                                    <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($option['id']); ?>"><?php echo e($option['nombre']); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php break; ?>
                                                <?php case ('zona_id'): ?>
                                                    <?php $__currentLoopData = $zonas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($option['id']); ?>"><?php echo e($option['nombre']); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php break; ?>
                                                <?php case ('categoria_id'): ?>
                                                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($option['id']); ?>"><?php echo e($option['nombre']); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php break; ?>
                                            <?php endswitch; ?>
                                        </select>
                                    <?php elseif($campos[$key]->Type == "boolean" || $campos[$key]->Type == "tinyint(1)"): ?>
                                        <select name="<?php echo e($campos[$key]->Field); ?>" id="<?php echo e($campos[$key]->Field); ?>" class="form-control <?php echo e($errors->has($campos[$key]->Field) ? 'is-invalid' : ''); ?>">
                                            <option value="">Seleccionar una opcion</option>
                                            <option value="1">Si</option>
                                            <option value="0">No</option>
                                        </select>
                                    <?php elseif($campos[$key]->Field == "comprobante" || $campos[$key]->Field == "imagen"): ?>
                                        <input type="file" name="<?php echo e($campos[$key]->Field); ?>" id="<?php echo e($campos[$key]->Field); ?>" class="form-control <?php echo e($errors->has($campos[$key]->Field) ? 'is-invalid' : ''); ?>" accept="image/*,.pdf">
                                    <?php else: ?>
                                        <?php if($campos[$key]->Type == "text" || $campos[$key]->Type == "varchar(255)"): ?>
                                            <input type="text" name="<?php echo e($campos[$key]->Field); ?>" id="<?php echo e($campos[$key]->Field); ?>" class="form-control <?php echo e($errors->has($campos[$key]->Field) ? 'is-invalid' : ''); ?>">
                                        <?php elseif($campos[$key]->Type == "integer" || $campos[$key]->Type == "bigint" || $campos[$key]->Type == "int" ): ?>
                                            <input type="number" name="<?php echo e($campos[$key]->Field); ?>" id="<?php echo e($campos[$key]->Field); ?>" class="form-control <?php echo e($errors->has($campos[$key]->Field) ? 'is-invalid' : ''); ?>">
                                        <?php elseif($campos[$key]->Type == "decimal(8,2)" || $campos[$key]->Type == "decimal" || $campos[$key]->Type == "float" || $campos[$key]->Type == "numeric" || $campos[$key]->Type == "double precision" || $campos[$key]->Type == "double"): ?>
                                            <input type="number" name="<?php echo e($campos[$key]->Field); ?>" id="<?php echo e($campos[$key]->Field); ?>" class="form-control <?php echo e($errors->has($campos[$key]->Field) ? 'is-invalid' : ''); ?>" step="any">
                                        <?php elseif($campos[$key]->Type == "date"): ?>
                                            <input type="date" name="<?php echo e($campos[$key]->Field); ?>" id="<?php echo e($campos[$key]->Field); ?>" class="form-control <?php echo e($errors->has($campos[$key]->Field) ? 'is-invalid' : ''); ?>">
                                        <?php endif; ?>
                                    <?php endif; ?>

                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="card-footer text-center">
                        <button class="btn btn-primary" type="button" id="enviar">Enviar</button>
                        <button class="btn btn-secondary" type="reset">Limpiar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script type="text/javascript">
        $("#enviar").on("click", function(e){
            e.preventDefault();
            var form = new FormData($("#NewRegister")[0]);
            $.ajax({
                type: "post",
                url: "<?php echo e($url); ?>",
                data: form,
                dataType: 'json',
                cache: false,
                contentType: false,
                processData: false,
                success: function (resp) {
                    if(resp.status == 'success'){
                        Swal.fire({
                            title: "Registro Exitoso!",
                            text: resp.msg,
                            icon: "success"
                        });
                        window.location.replace("/home");
                    }else{
                        Swal.fire({
                            title: "Registro Exitoso!",
                            text: resp.msg,
                            icon: "success"
                        });
                    }
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alexander Torres\Desktop\workspace\ervzla.com\admin\resources\views/form.blade.php ENDPATH**/ ?>